# 01 — Bắt đầu với React Native (Expo)

Source demo cho môn **IN420303 — Lập trình thiết bị di động**.
Ứng dụng minh họa những kiến thức nền tảng đầu tiên của React Native, viết bằng
**TypeScript** và điều hướng bằng **Expo Router** (file-based routing).

---

## 1. Yêu cầu chuẩn bị

- **Node.js 18+** (khuyến nghị bản LTS).
- Điện thoại cài app **Expo Go** (Android/iOS) — hoặc máy ảo Android/iOS.
- Trình soạn thảo: **VS Code**.

## 2. Cách chạy

```bash
# Cài dependencies (chỉ cần lần đầu)
npm install

# Khởi động dev server
npx expo start
```

Sau đó:

- **Điện thoại thật:** mở app *Expo Go* → quét mã QR hiện trên terminal.
- **Máy ảo Android:** bấm `a` trong terminal.
- **Máy ảo iOS (macOS):** bấm `i`.
- **Trên trình duyệt:** bấm `w`.

> 💡 Sửa code rồi lưu (Ctrl/Cmd + S) → app tự cập nhật ngay (Fast Refresh).

## 3. Cấu trúc dự án

```
01-bat-dau-voi-react-native/
├── app/                      # Mỗi file = một route (Expo Router)
│   ├── _layout.tsx           # Layout gốc (Stack + SafeAreaProvider)
│   └── (tabs)/               # Nhóm tab (dấu () = không hiện trên URL)
│       ├── _layout.tsx       # Khai báo thanh tab dưới màn hình
│       ├── index.tsx         # 🏠 Giới thiệu (route "/")
│       ├── components.tsx    # 🧱 Core Components & JSX
│       ├── styling.tsx       # 🎨 StyleSheet & Flexbox
│       ├── state.tsx         # ⚡ State & Props (useState)
│       └── list.tsx          # 📝 FlatList + TextInput + Pressable
├── components/               # Component tái sử dụng
│   ├── Section.tsx           # "Thẻ bài học" (ví dụ props + children)
│   └── DemoCounter.tsx       # Ví dụ props + useState
├── constants/theme.ts        # Bảng màu, spacing, bo góc dùng chung
├── assets/                   # Icon, ảnh
├── app.json                  # Cấu hình Expo
├── package.json
└── tsconfig.json
```

## 4. Nội dung từng bài

| Tab | Học được gì |
|-----|-------------|
| 🏠 **Giới thiệu** | React Native/Expo là gì, cách chạy app, `<Link>` để điều hướng |
| 🧱 **Components** | `View`, `Text`, `Image` (từ máy & từ mạng), `ScrollView`, nhúng biểu thức trong JSX bằng `{}` |
| 🎨 **Styling** | `StyleSheet.create`, Flexbox (`flexDirection`, `justifyContent`, `alignItems`, `flex`), gộp nhiều style bằng mảng |
| ⚡ **State** | `useState`, khác biệt giữa **props** (chỉ đọc) và **state** (thay đổi được), component tái sử dụng |
| 📝 **List** | App mini To-Do: `TextInput`, `Pressable`, `FlatList`, cách cập nhật mảng trong state bằng `...spread`, `.map`, `.filter` |

## 5. Ghi chú kỹ thuật

- **Mọi chữ phải nằm trong `<Text>`** — đây là lỗi hay gặp nhất của người mới.
- **Không sửa trực tiếp state** — luôn dùng hàm `setXxx` với giá trị/mảng mới.
- **Expo Router** dựa trên tên file: đổi tên file trong `app/` là đổi route.
- Toàn bộ code có **comment tiếng Việt** giải thích từng phần — hãy đọc kèm khi chạy.

## 6. Gợi ý bài tập mở rộng

1. Thêm nút "Xoá tất cả" ở màn hình List.
2. Cho phép sửa nội dung một việc đã tạo.
3. Thêm một tab mới `profile.tsx` hiển thị thông tin sinh viên.
4. Đổi bảng màu trong `constants/theme.ts` sang tông màu bạn thích.
