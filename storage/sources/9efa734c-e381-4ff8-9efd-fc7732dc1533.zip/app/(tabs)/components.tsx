/**
 * Bài 1 — CORE COMPONENTS & JSX (route "/components").
 *
 * Giới thiệu các component nền tảng:
 *  - View  : hộp chứa (giống <div> trên web).
 *  - Text  : mọi chữ PHẢI nằm trong <Text>.
 *  - Image : ảnh, lấy từ máy (require) hoặc từ mạng (uri).
 *  - ScrollView : vùng cuộn được khi nội dung dài.
 *
 * JSX là cú pháp giống HTML nhưng nằm trong JavaScript/TypeScript.
 */

import { Image, ScrollView, StyleSheet, Text, View } from "react-native";
import Section from "../../components/Section";
import { colors, radius, spacing } from "../../constants/theme";

export default function ComponentsScreen() {
  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <Section
        title="View & Text"
        description="View là hộp chứa; Text để hiển thị chữ. Không đặt chữ trực tiếp ngoài <Text>."
      >
        <View style={styles.box}>
          <Text style={styles.boxText}>Mình nằm trong một &lt;View&gt;</Text>
        </View>
      </Section>

      <Section
        title="Image — ảnh từ máy"
        description="Dùng require() cho ảnh nằm trong dự án (assets)."
      >
        <Image
          source={require("../../assets/icon.png")}
          style={styles.localImage}
        />
      </Section>

      <Section
        title="Image — ảnh từ mạng"
        description="Dùng source={{ uri: '...' }} và BẮT BUỘC đặt width/height."
      >
        <Image
          source={{ uri: "https://reactnative.dev/img/tiny_logo.png" }}
          style={styles.remoteImage}
        />
      </Section>

      <Section
        title="JSX nhúng biểu thức"
        description="Dùng {} để chèn giá trị JavaScript vào giao diện."
      >
        <Text style={styles.paragraph}>
          2 + 3 = {2 + 3}. Hôm nay là năm {new Date().getFullYear()}.
        </Text>
      </Section>

      <Section
        title="ScrollView"
        description="Cả màn hình này chính là một ScrollView — kéo lên xuống để xem hết nội dung."
      >
        <Text style={styles.paragraph}>
          Khi nội dung cao hơn màn hình, hãy bọc trong ScrollView (hoặc FlatList
          cho danh sách dài) để người dùng cuộn được.
        </Text>
      </Section>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.md,
  },
  box: {
    backgroundColor: colors.primary,
    padding: spacing.md,
    borderRadius: radius.sm,
  },
  boxText: {
    color: colors.white,
    fontWeight: "600",
  },
  localImage: {
    width: 96,
    height: 96,
    borderRadius: radius.md,
  },
  remoteImage: {
    width: 120,
    height: 60,
    resizeMode: "contain",
  },
  paragraph: {
    fontSize: 14,
    lineHeight: 21,
    color: colors.text,
  },
});
