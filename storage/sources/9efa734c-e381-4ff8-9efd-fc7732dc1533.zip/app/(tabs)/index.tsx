/**
 * Màn hình GIỚI THIỆU (route "/").
 *
 * Mục tiêu: giải thích React Native + Expo là gì và dẫn tới từng bài học.
 * Dùng <Link> của Expo Router để chuyển sang tab khác bằng đường dẫn (href).
 */

import { Link } from "expo-router";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import Section from "../../components/Section";
import { colors, radius, spacing } from "../../constants/theme";

// Danh sách các bài học để render nhanh bằng .map()
const lessons = [
  { href: "/components", emoji: "🧱", title: "Components & JSX", desc: "View, Text, Image, ScrollView" },
  { href: "/styling", emoji: "🎨", title: "Styling & Flexbox", desc: "StyleSheet, bố cục co giãn" },
  { href: "/state", emoji: "⚡", title: "State & Props", desc: "useState, truyền dữ liệu" },
  { href: "/list", emoji: "📝", title: "List & Input", desc: "FlatList, TextInput, nút bấm" },
] as const;

export default function HomeScreen() {
  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={styles.content}
    >
      <Text style={{color: 'red'}}>Bắt đầu với React Native Lớp 303</Text>
      <Text style={styles.subtitle}>Xây dựng ứng dụng di động bằng Expo</Text>

      <Section
        title="React Native là gì?"
        description="Framework của Meta cho phép viết ứng dụng iOS & Android bằng React (JavaScript/TypeScript). Code một lần, chạy trên nhiều nền tảng."
      >
        <Text style={styles.paragraph}>
          Thay vì dùng thẻ HTML như trên web, ta dùng các component gốc như{" "}
          <Text style={styles.code}>View</Text>,{" "}
          <Text style={styles.code}>Text</Text>,{" "}
          <Text style={styles.code}>Image</Text>.
        </Text>
      </Section>

      <Section
        title="Expo là gì?"
        description="Bộ công cụ giúp chạy, thử và đóng gói ứng dụng React Native dễ dàng — không cần cấu hình Android Studio/Xcode phức tạp."
      >
        <Text style={styles.paragraph}>
          Chạy lệnh <Text style={styles.code}>npx expo start</Text> rồi quét mã QR
          bằng app <Text style={styles.code}>Expo Go</Text> trên điện thoại để xem
          ngay kết quả.
        </Text>
      </Section>

      <Section title="Các bài học" description="Bấm vào từng bài hoặc dùng thanh tab bên dưới.">
        {lessons.map((lesson) => (
          // asChild để <Link> biến phần tử con thành vùng bấm được
          <Link key={lesson.href} href={lesson.href} asChild>
            <View style={styles.lessonRow}>
              <Text style={styles.lessonEmoji}>{lesson.emoji}</Text>
              <View style={styles.lessonTextBox}>
                <Text style={styles.lessonTitle}>{lesson.title}</Text>
                <Text style={styles.lessonDesc}>{lesson.desc}</Text>
              </View>
              <Text style={styles.chevron}>›</Text>
            </View>
          </Link>
        ))}
      </Section>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.md,
  },
  h1: {
    fontSize: 26,
    fontWeight: "800",
    color: colors.text,
  },
  subtitle: {
    fontSize: 15,
    color: colors.muted,
    marginTop: spacing.xs,
    marginBottom: spacing.md,
  },
  paragraph: {
    fontSize: 14,
    lineHeight: 21,
    color: colors.text,
  },
  code: {
    fontFamily: "monospace",
    color: colors.primaryDark,
    backgroundColor: "#eef2ff",
  },
  lessonRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    gap: spacing.md,
  },
  lessonEmoji: {
    fontSize: 24,
  },
  lessonTextBox: {
    flex: 1, // chiếm hết khoảng trống còn lại
  },
  lessonTitle: {
    fontSize: 15,
    fontWeight: "700",
    color: colors.text,
  },
  lessonDesc: {
    fontSize: 13,
    color: colors.muted,
  },
  chevron: {
    fontSize: 24,
    color: colors.muted,
  },
});
