/**
 * Bài 4 — LIST, TEXTINPUT & TOUCHABLE (route "/list").
 *
 * Ứng dụng mini "Việc cần làm" (To-Do) kết hợp:
 *  - TextInput : ô nhập liệu, gắn với state `text`.
 *  - Pressable : nút bấm để thêm / xoá / gạch bỏ.
 *  - FlatList  : hiển thị danh sách hiệu quả (chỉ vẽ phần đang thấy).
 *
 * Với mảng trong state: LUÔN tạo mảng MỚI (dùng ...spread) rồi gọi setTodos,
 * không sửa trực tiếp mảng cũ.
 */

import { useState } from "react";
import {
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { colors, radius, spacing } from "../../constants/theme";

// Kiểu dữ liệu của một việc cần làm
type Todo = {
  id: string;
  text: string;
  done: boolean;
};

export default function ListScreen() {
  const [text, setText] = useState(""); // nội dung đang gõ
  const [todos, setTodos] = useState<Todo[]>([
    { id: "1", text: "Cài đặt Expo Go trên điện thoại", done: true },
    { id: "2", text: "Chạy npx expo start", done: false },
    { id: "3", text: "Sửa code và xem app tự cập nhật", done: false },
  ]);

  // Thêm việc mới vào ĐẦU danh sách
  function addTodo() {
    const value = text.trim();
    if (value.length === 0) return; // bỏ qua nếu rỗng
    const newTodo: Todo = {
      id: Date.now().toString(), // id đơn giản dựa trên thời gian
      text: value,
      done: false,
    };
    setTodos([newTodo, ...todos]); // tạo mảng mới
    setText(""); // xoá ô nhập
  }

  // Gạch bỏ / bỏ gạch một việc
  function toggleTodo(id: string) {
    setTodos(
      todos.map((t) => (t.id === id ? { ...t, done: !t.done } : t))
    );
  }

  // Xoá một việc khỏi danh sách
  function removeTodo(id: string) {
    setTodos(todos.filter((t) => t.id !== id));
  }

  return (
    <View style={styles.screen}>
      {/* Khu vực nhập liệu */}
      <View style={styles.inputRow}>
        <TextInput
          style={styles.input}
          placeholder="Nhập việc cần làm..."
          value={text}
          onChangeText={setText} // mỗi ký tự gõ vào cập nhật state
          onSubmitEditing={addTodo} // bấm Enter trên bàn phím cũng thêm
          returnKeyType="done"
        />
        <Pressable style={styles.addButton} onPress={addTodo}>
          <Text style={styles.addButtonText}>Thêm</Text>
        </Pressable>
      </View>

      {/* Danh sách việc — FlatList */}
      <FlatList
        data={todos}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <Text style={styles.empty}>Chưa có việc nào. Hãy thêm một việc!</Text>
        }
        renderItem={({ item }) => (
          <View style={styles.item}>
            {/* Chạm vào nội dung để gạch bỏ */}
            <Pressable style={styles.itemContent} onPress={() => toggleTodo(item.id)}>
              <Text style={styles.checkbox}>{item.done ? "☑" : "☐"}</Text>
              <Text style={[styles.itemText, item.done && styles.itemTextDone]}>
                {item.text}
              </Text>
            </Pressable>

            <Pressable onPress={() => removeTodo(item.id)} hitSlop={8}>
              <Text style={styles.deleteText}>Xoá</Text>
            </Pressable>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  inputRow: {
    flexDirection: "row",
    gap: spacing.sm,
    padding: spacing.md,
  },
  input: {
    flex: 1,
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    fontSize: 15,
  },
  addButton: {
    backgroundColor: colors.primary,
    borderRadius: radius.sm,
    paddingHorizontal: spacing.md,
    justifyContent: "center",
  },
  addButtonText: {
    color: colors.white,
    fontWeight: "700",
  },
  listContent: {
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.lg,
  },
  item: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.card,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    marginBottom: spacing.sm,
  },
  itemContent: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
  },
  checkbox: {
    fontSize: 20,
    color: colors.primary,
  },
  itemText: {
    fontSize: 15,
    color: colors.text,
    flexShrink: 1,
  },
  itemTextDone: {
    textDecorationLine: "line-through",
    color: colors.muted,
  },
  deleteText: {
    color: colors.danger,
    fontWeight: "600",
    marginLeft: spacing.sm,
  },
  empty: {
    textAlign: "center",
    color: colors.muted,
    marginTop: spacing.xl,
  },
});
