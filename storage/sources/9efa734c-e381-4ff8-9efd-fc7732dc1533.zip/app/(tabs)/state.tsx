/**
 * Bài 3 — STATE & PROPS (route "/state").
 *
 *  - PROPS : dữ liệu cha truyền cho con, con chỉ ĐỌC (xem DemoCounter).
 *  - STATE : dữ liệu nội bộ của component, thay đổi bằng hàm set → giao diện tự vẽ lại.
 *
 * Quy tắc vàng: KHÔNG sửa trực tiếp biến state, luôn gọi hàm setXxx().
 */

import { useState } from "react";
import { Pressable, ScrollView, StyleSheet, Switch, Text, View } from "react-native";
import DemoCounter from "../../components/DemoCounter";
import Section from "../../components/Section";
import { colors, radius, spacing } from "../../constants/theme";

export default function StateScreen() {
  // 1) State kiểu boolean cho công tắc bật/tắt
  const [isOn, setIsOn] = useState(false);

  // 2) State kiểu số, tự đổi màu nền theo số lần bấm
  const [taps, setTaps] = useState(0);
  const palette = ["#2563eb", "#16a34a", "#dc2626", "#9333ea", "#ea580c"];
  const bgColor = palette[taps % palette.length];

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <Section
        title="Component tái sử dụng với props khác nhau"
        description="Cùng <DemoCounter/> nhưng truyền label và step khác nhau."
      >
        {/* Mỗi counter giữ state riêng của nó */}
        <DemoCounter label="Bộ đếm bước 1" />
        <DemoCounter label="Bộ đếm bước 5" step={5} />
      </Section>

      <Section
        title="State boolean + Switch"
        description="Switch đọc/ghi vào state isOn."
      >
        <View style={styles.row}>
          <Text style={styles.paragraph}>
            Trạng thái: {isOn ? "BẬT 🔛" : "TẮT ⬛"}
          </Text>
          <Switch value={isOn} onValueChange={setIsOn} />
        </View>
      </Section>

      <Section
        title="State điều khiển giao diện"
        description="Mỗi lần bấm, đổi màu nền theo số lần bấm."
      >
        <Pressable
          style={[styles.tapBox, { backgroundColor: bgColor }]}
          onPress={() => setTaps(taps + 1)}
        >
          <Text style={styles.tapText}>Đã bấm {taps} lần</Text>
          <Text style={styles.tapHint}>Chạm để +1 và đổi màu</Text>
        </Pressable>
        <Pressable style={styles.resetButton} onPress={() => setTaps(0)}>
          <Text style={styles.resetText}>Đặt lại (reset về 0)</Text>
        </Pressable>
      </Section>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.md,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  paragraph: {
    fontSize: 15,
    color: colors.text,
  },
  tapBox: {
    borderRadius: radius.md,
    padding: spacing.lg,
    alignItems: "center",
  },
  tapText: {
    color: colors.white,
    fontSize: 20,
    fontWeight: "800",
  },
  tapHint: {
    color: colors.white,
    opacity: 0.85,
    marginTop: spacing.xs,
  },
  resetButton: {
    marginTop: spacing.sm,
    alignSelf: "flex-start",
    paddingVertical: spacing.xs,
  },
  resetText: {
    color: colors.primary,
    fontWeight: "600",
  },
});
