/**
 * Bài 2 — STYLING & FLEXBOX (route "/styling").
 *
 *  - StyleSheet.create({...}) để định nghĩa style (giống CSS nhưng viết bằng object).
 *  - React Native dùng Flexbox để bố cục. Mặc định flexDirection là "column".
 *  - Các thuộc tính hay dùng: flexDirection, justifyContent, alignItems, gap, flex.
 */

import { ScrollView, StyleSheet, Text, View } from "react-native";
import Section from "../../components/Section";
import { colors, radius, spacing } from "../../constants/theme";

// Ô vuông màu để minh họa bố cục
function Box({ label }: { label: string }) {
  return (
    <View style={styles.box}>
      <Text style={styles.boxText}>{label}</Text>
    </View>
  );
}

export default function StylingScreen() {
  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <Section
        title="flexDirection: 'row'"
        description="Xếp các phần tử theo hàng ngang."
      >
        <View style={[styles.demo, { flexDirection: "row", gap: spacing.sm }]}>
          <Box label="1" />
          <Box label="2" />
          <Box label="3" />
        </View>
      </Section>

      <Section
        title="justifyContent: 'space-between'"
        description="Chia đều khoảng cách theo trục chính (ở đây là ngang)."
      >
        <View style={[styles.demo, { flexDirection: "row", justifyContent: "space-between" }]}>
          <Box label="A" />
          <Box label="B" />
          <Box label="C" />
        </View>
      </Section>

      <Section
        title="alignItems: 'center'"
        description="Căn giữa theo trục phụ (ở đây là dọc)."
      >
        <View style={[styles.demoTall, { flexDirection: "row", alignItems: "center", gap: spacing.sm }]}>
          <Box label="x" />
          <Box label="y" />
        </View>
      </Section>

      <Section
        title="flex: 1 — chia tỉ lệ"
        description="flex: 2 rộng gấp đôi flex: 1."
      >
        <View style={[styles.demo, { flexDirection: "row", gap: spacing.sm }]}>
          <View style={[styles.flexBox, { flex: 1, backgroundColor: colors.primary }]}>
            <Text style={styles.boxText}>flex 1</Text>
          </View>
          <View style={[styles.flexBox, { flex: 2, backgroundColor: colors.success }]}>
            <Text style={styles.boxText}>flex 2</Text>
          </View>
        </View>
      </Section>

      <Section
        title="Gộp nhiều style"
        description="Truyền một mảng [styleA, styleB] — style sau ghi đè style trước."
      >
        <View style={[styles.card, styles.cardHighlight]}>
          <Text style={styles.paragraph}>
            Ô này dùng style="{'{'}[styles.card, styles.cardHighlight]{'}'}"
          </Text>
        </View>
      </Section>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: spacing.md,
  },
  demo: {
    backgroundColor: "#e2e8f0",
    borderRadius: radius.sm,
    padding: spacing.sm,
  },
  demoTall: {
    backgroundColor: "#e2e8f0",
    borderRadius: radius.sm,
    padding: spacing.sm,
    height: 96,
  },
  box: {
    backgroundColor: colors.primary,
    width: 48,
    height: 48,
    borderRadius: radius.sm,
    alignItems: "center",
    justifyContent: "center",
  },
  boxText: {
    color: colors.white,
    fontWeight: "700",
  },
  flexBox: {
    height: 48,
    borderRadius: radius.sm,
    alignItems: "center",
    justifyContent: "center",
  },
  card: {
    padding: spacing.md,
    borderRadius: radius.sm,
    backgroundColor: colors.card,
  },
  cardHighlight: {
    borderWidth: 2,
    borderColor: colors.primary,
    backgroundColor: "#eff6ff",
  },
  paragraph: {
    fontSize: 14,
    color: colors.text,
  },
});
