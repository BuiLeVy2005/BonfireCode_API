/**
 * app/_layout.tsx — Layout GỐC của toàn app (Expo Router).
 *
 * Expo Router dùng "file-based routing": mỗi file trong thư mục `app/` là một route.
 *  - `_layout.tsx` là khung bao ngoài, không phải một trang.
 *  - <Stack> quản lý điều hướng dạng ngăn xếp; ở đây nó chứa nhóm (tabs).
 *  - <SafeAreaProvider> cần cho việc tính vùng an toàn (tai thỏ, thanh điều hướng).
 */

import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      {/* Ẩn header của Stack vì phần tabs bên trong đã có header riêng */}
      <Stack screenOptions={{ headerShown: false }} />
      <StatusBar style="dark" />
    </SafeAreaProvider>
  );
}
