/**
 * DemoCounter.tsx — Ví dụ kết hợp PROPS + STATE.
 *
 *  - PROPS: `label` và `step` được truyền từ component cha xuống (dữ liệu chỉ đọc).
 *  - STATE: `count` là dữ liệu nội bộ, thay đổi được bằng setCount → giao diện tự vẽ lại.
 *
 * Cùng một component có thể tái sử dụng với props khác nhau (xem màn hình State).
 */

import { useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { colors, radius, spacing } from "../constants/theme";

type DemoCounterProps = {
  label: string;
  step?: number; // bước tăng/giảm, mặc định 1
};

export default function DemoCounter({ label, step = 1 }: DemoCounterProps) {
  // useState trả về [giá trị hiện tại, hàm cập nhật]
  const [count, setCount] = useState(0);

  return (
    <View style={styles.wrapper}>
      <Text style={styles.label}>{label}</Text>

      <View style={styles.row}>
        <Pressable
          style={styles.button}
          onPress={() => setCount(count - step)} // cập nhật state → re-render
        >
          <Text style={styles.buttonText}>−{step}</Text>
        </Pressable>

        <Text style={styles.count}>{count}</Text>

        <Pressable style={styles.button} onPress={() => setCount(count + step)}>
          <Text style={styles.buttonText}>+{step}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    marginBottom: spacing.md,
  },
  label: {
    fontSize: 15,
    fontWeight: "600",
    color: colors.text,
    marginBottom: spacing.sm,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
  },
  button: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: radius.sm,
    minWidth: 56,
    alignItems: "center",
  },
  buttonText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: "700",
  },
  count: {
    fontSize: 24,
    fontWeight: "800",
    color: colors.text,
    minWidth: 48,
    textAlign: "center",
  },
});
