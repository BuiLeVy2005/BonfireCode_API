/**
 * Section.tsx — Một "thẻ bài học" dùng lại nhiều lần.
 *
 * Đây là ví dụ về COMPONENT TÁI SỬ DỤNG + PROPS:
 *  - Nhận vào `title`, `description` (tùy chọn) và `children`.
 *  - `children` là nội dung nằm giữa <Section>...</Section>.
 */

import { ReactNode } from "react";
import { StyleSheet, Text, View } from "react-native";
import { colors, radius, spacing } from "../constants/theme";

type SectionProps = {
  title: string; // tiêu đề bắt buộc
  description?: string; // mô tả tùy chọn (dấu ? = optional)
  children: ReactNode; // nội dung bên trong thẻ
};

export default function Section({ title, description, children }: SectionProps) {
  return (
    <View style={styles.card}>
      <Text style={styles.title}>{title}</Text>
      {/* Chỉ hiển thị mô tả khi có truyền vào */}
      {description ? <Text style={styles.description}>{description}</Text> : null}
      <View style={styles.body}>{children}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  title: {
    fontSize: 18,
    fontWeight: "700",
    color: colors.text,
  },
  description: {
    fontSize: 14,
    color: colors.muted,
    marginTop: spacing.xs,
  },
  body: {
    marginTop: spacing.md,
  },
});
