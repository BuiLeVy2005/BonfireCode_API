/**
 * theme.ts — Bảng màu, khoảng cách, bo góc dùng chung cho cả app.
 *
 * Tách các giá trị thiết kế ra một chỗ giúp:
 *  - Giao diện đồng nhất giữa các màn hình.
 *  - Đổi màu/khoảng cách chỉ cần sửa một nơi.
 */

export const colors = {
  primary: "#2563eb", // xanh dương chủ đạo
  primaryDark: "#1e40af",
  background: "#f1f5f9", // nền màn hình
  card: "#ffffff", // nền thẻ
  text: "#0f172a", // chữ chính
  muted: "#64748b", // chữ phụ
  border: "#e2e8f0",
  success: "#16a34a",
  danger: "#dc2626",
  white: "#ffffff",
};

// Khoảng cách (padding/margin) theo bậc để layout đều nhau.
export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
};

// Bo góc.
export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
};
